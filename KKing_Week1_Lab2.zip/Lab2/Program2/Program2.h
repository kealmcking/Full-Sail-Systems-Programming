﻿#include <iostream>

using namespace std;

void PrintParams(int _number, int* _ptr)
{
    cout << "Value: " << _number << ", Address: " << _ptr << "." << "\n";
}